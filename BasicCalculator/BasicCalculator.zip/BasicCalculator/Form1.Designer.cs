﻿namespace BasicCalculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Result2 = new System.Windows.Forms.TextBox();
            this.Result1 = new System.Windows.Forms.TextBox();
            this.button_Neg = new System.Windows.Forms.Button();
            this.button_0 = new System.Windows.Forms.Button();
            this.button_Perc = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button_SqR = new System.Windows.Forms.Button();
            this.button_1 = new System.Windows.Forms.Button();
            this.button_sq = new System.Windows.Forms.Button();
            this.button_2 = new System.Windows.Forms.Button();
            this.button_fact = new System.Windows.Forms.Button();
            this.button_3 = new System.Windows.Forms.Button();
            this.button_4 = new System.Windows.Forms.Button();
            this.button_5 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button_6 = new System.Windows.Forms.Button();
            this.button_ClearResult = new System.Windows.Forms.Button();
            this.button_7 = new System.Windows.Forms.Button();
            this.button_div = new System.Windows.Forms.Button();
            this.button_8 = new System.Windows.Forms.Button();
            this.button_Clear = new System.Windows.Forms.Button();
            this.button_9 = new System.Windows.Forms.Button();
            this.button_Eq = new System.Windows.Forms.Button();
            this.button_Multi = new System.Windows.Forms.Button();
            this.button_Add = new System.Windows.Forms.Button();
            this.button_Sub = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button_Convert = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(-7, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(418, 507);
            this.panel1.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, -1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(411, 501);
            this.tabControl1.TabIndex = 28;
            // 
            // tabPage1
            // 
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.Result2);
            this.tabPage1.Controls.Add(this.Result1);
            this.tabPage1.Controls.Add(this.button_Neg);
            this.tabPage1.Controls.Add(this.button_0);
            this.tabPage1.Controls.Add(this.button_Perc);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button_SqR);
            this.tabPage1.Controls.Add(this.button_1);
            this.tabPage1.Controls.Add(this.button_sq);
            this.tabPage1.Controls.Add(this.button_2);
            this.tabPage1.Controls.Add(this.button_fact);
            this.tabPage1.Controls.Add(this.button_3);
            this.tabPage1.Controls.Add(this.button_4);
            this.tabPage1.Controls.Add(this.button_5);
            this.tabPage1.Controls.Add(this.button10);
            this.tabPage1.Controls.Add(this.button_6);
            this.tabPage1.Controls.Add(this.button_ClearResult);
            this.tabPage1.Controls.Add(this.button_7);
            this.tabPage1.Controls.Add(this.button_div);
            this.tabPage1.Controls.Add(this.button_8);
            this.tabPage1.Controls.Add(this.button_Clear);
            this.tabPage1.Controls.Add(this.button_9);
            this.tabPage1.Controls.Add(this.button_Eq);
            this.tabPage1.Controls.Add(this.button_Multi);
            this.tabPage1.Controls.Add(this.button_Add);
            this.tabPage1.Controls.Add(this.button_Sub);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(403, 472);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Basic Calculator";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // Result2
            // 
            this.Result2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Result2.Enabled = false;
            this.Result2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Result2.ForeColor = System.Drawing.Color.DarkGray;
            this.Result2.Location = new System.Drawing.Point(0, 0);
            this.Result2.Multiline = true;
            this.Result2.Name = "Result2";
            this.Result2.Size = new System.Drawing.Size(400, 81);
            this.Result2.TabIndex = 21;
            this.Result2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Result1
            // 
            this.Result1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Result1.Location = new System.Drawing.Point(0, 76);
            this.Result1.MaxLength = 8;
            this.Result1.Multiline = true;
            this.Result1.Name = "Result1";
            this.Result1.Size = new System.Drawing.Size(400, 66);
            this.Result1.TabIndex = 20;
            this.Result1.Text = "0";
            this.Result1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button_Neg
            // 
            this.button_Neg.BackColor = System.Drawing.Color.White;
            this.button_Neg.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Neg.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Neg.Location = new System.Drawing.Point(0, 415);
            this.button_Neg.Name = "button_Neg";
            this.button_Neg.Size = new System.Drawing.Size(105, 56);
            this.button_Neg.TabIndex = 0;
            this.button_Neg.Text = "+/-";
            this.button_Neg.UseVisualStyleBackColor = false;
            this.button_Neg.Click += new System.EventHandler(this.button_Neg_Click);
            // 
            // button_0
            // 
            this.button_0.BackColor = System.Drawing.Color.White;
            this.button_0.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_0.Location = new System.Drawing.Point(99, 415);
            this.button_0.Name = "button_0";
            this.button_0.Size = new System.Drawing.Size(105, 56);
            this.button_0.TabIndex = 1;
            this.button_0.Text = "0";
            this.button_0.UseVisualStyleBackColor = false;
            this.button_0.Click += new System.EventHandler(this.ClickedButtonValue);
            // 
            // button_Perc
            // 
            this.button_Perc.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_Perc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Perc.Location = new System.Drawing.Point(297, 141);
            this.button_Perc.Name = "button_Perc";
            this.button_Perc.Size = new System.Drawing.Size(105, 56);
            this.button_Perc.TabIndex = 25;
            this.button_Perc.Text = "%";
            this.button_Perc.UseVisualStyleBackColor = false;
            this.button_Perc.Click += new System.EventHandler(this.OperationPerform);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button3.Location = new System.Drawing.Point(198, 415);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(105, 56);
            this.button3.TabIndex = 2;
            this.button3.Text = ".";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.ClickedButtonValue);
            // 
            // button_SqR
            // 
            this.button_SqR.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_SqR.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_SqR.Location = new System.Drawing.Point(198, 141);
            this.button_SqR.Name = "button_SqR";
            this.button_SqR.Size = new System.Drawing.Size(105, 56);
            this.button_SqR.TabIndex = 24;
            this.button_SqR.Text = "SqRoot";
            this.button_SqR.UseVisualStyleBackColor = false;
            this.button_SqR.Click += new System.EventHandler(this.OperationPerform);
            // 
            // button_1
            // 
            this.button_1.BackColor = System.Drawing.Color.White;
            this.button_1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_1.Location = new System.Drawing.Point(0, 360);
            this.button_1.Name = "button_1";
            this.button_1.Size = new System.Drawing.Size(105, 56);
            this.button_1.TabIndex = 3;
            this.button_1.Text = "1";
            this.button_1.UseVisualStyleBackColor = false;
            this.button_1.Click += new System.EventHandler(this.ClickedButtonValue);
            // 
            // button_sq
            // 
            this.button_sq.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_sq.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_sq.Location = new System.Drawing.Point(99, 141);
            this.button_sq.Name = "button_sq";
            this.button_sq.Size = new System.Drawing.Size(105, 56);
            this.button_sq.TabIndex = 23;
            this.button_sq.Text = "x^2";
            this.button_sq.UseVisualStyleBackColor = false;
            this.button_sq.Click += new System.EventHandler(this.OperationPerform);
            // 
            // button_2
            // 
            this.button_2.BackColor = System.Drawing.Color.White;
            this.button_2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_2.Location = new System.Drawing.Point(99, 360);
            this.button_2.Name = "button_2";
            this.button_2.Size = new System.Drawing.Size(105, 56);
            this.button_2.TabIndex = 4;
            this.button_2.Text = "2";
            this.button_2.UseVisualStyleBackColor = false;
            this.button_2.Click += new System.EventHandler(this.ClickedButtonValue);
            // 
            // button_fact
            // 
            this.button_fact.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_fact.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_fact.Location = new System.Drawing.Point(0, 141);
            this.button_fact.Name = "button_fact";
            this.button_fact.Size = new System.Drawing.Size(105, 56);
            this.button_fact.TabIndex = 22;
            this.button_fact.Text = "1/x";
            this.button_fact.UseVisualStyleBackColor = false;
            this.button_fact.Click += new System.EventHandler(this.OperationPerform);
            // 
            // button_3
            // 
            this.button_3.BackColor = System.Drawing.Color.White;
            this.button_3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_3.Location = new System.Drawing.Point(198, 360);
            this.button_3.Name = "button_3";
            this.button_3.Size = new System.Drawing.Size(105, 56);
            this.button_3.TabIndex = 5;
            this.button_3.Text = "3";
            this.button_3.UseVisualStyleBackColor = false;
            this.button_3.Click += new System.EventHandler(this.ClickedButtonValue);
            // 
            // button_4
            // 
            this.button_4.BackColor = System.Drawing.Color.White;
            this.button_4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_4.Location = new System.Drawing.Point(0, 305);
            this.button_4.Name = "button_4";
            this.button_4.Size = new System.Drawing.Size(105, 56);
            this.button_4.TabIndex = 6;
            this.button_4.Text = "4";
            this.button_4.UseVisualStyleBackColor = false;
            this.button_4.Click += new System.EventHandler(this.ClickedButtonValue);
            // 
            // button_5
            // 
            this.button_5.BackColor = System.Drawing.Color.White;
            this.button_5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_5.Location = new System.Drawing.Point(99, 305);
            this.button_5.Name = "button_5";
            this.button_5.Size = new System.Drawing.Size(105, 56);
            this.button_5.TabIndex = 7;
            this.button_5.Text = "5";
            this.button_5.UseVisualStyleBackColor = false;
            this.button_5.Click += new System.EventHandler(this.ClickedButtonValue);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button10.Location = new System.Drawing.Point(0, 195);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(105, 56);
            this.button10.TabIndex = 19;
            this.button10.Text = "<<";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button_BackSpace);
            // 
            // button_6
            // 
            this.button_6.BackColor = System.Drawing.Color.White;
            this.button_6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_6.Location = new System.Drawing.Point(198, 305);
            this.button_6.Name = "button_6";
            this.button_6.Size = new System.Drawing.Size(105, 56);
            this.button_6.TabIndex = 8;
            this.button_6.Text = "6";
            this.button_6.UseVisualStyleBackColor = false;
            this.button_6.Click += new System.EventHandler(this.ClickedButtonValue);
            // 
            // button_ClearResult
            // 
            this.button_ClearResult.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_ClearResult.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_ClearResult.Location = new System.Drawing.Point(99, 195);
            this.button_ClearResult.Name = "button_ClearResult";
            this.button_ClearResult.Size = new System.Drawing.Size(105, 56);
            this.button_ClearResult.TabIndex = 18;
            this.button_ClearResult.Text = "CE";
            this.button_ClearResult.UseVisualStyleBackColor = false;
            this.button_ClearResult.Click += new System.EventHandler(this.button_ClearResult_Click);
            // 
            // button_7
            // 
            this.button_7.BackColor = System.Drawing.Color.White;
            this.button_7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_7.Location = new System.Drawing.Point(0, 250);
            this.button_7.Name = "button_7";
            this.button_7.Size = new System.Drawing.Size(105, 56);
            this.button_7.TabIndex = 9;
            this.button_7.Text = "7";
            this.button_7.UseVisualStyleBackColor = false;
            this.button_7.Click += new System.EventHandler(this.ClickedButtonValue);
            // 
            // button_div
            // 
            this.button_div.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_div.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_div.Location = new System.Drawing.Point(297, 195);
            this.button_div.Name = "button_div";
            this.button_div.Size = new System.Drawing.Size(105, 56);
            this.button_div.TabIndex = 17;
            this.button_div.Text = "/";
            this.button_div.UseVisualStyleBackColor = false;
            this.button_div.Click += new System.EventHandler(this.OperationPerform);
            // 
            // button_8
            // 
            this.button_8.BackColor = System.Drawing.Color.White;
            this.button_8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_8.Location = new System.Drawing.Point(99, 250);
            this.button_8.Name = "button_8";
            this.button_8.Size = new System.Drawing.Size(105, 56);
            this.button_8.TabIndex = 10;
            this.button_8.Text = "8";
            this.button_8.UseVisualStyleBackColor = false;
            this.button_8.Click += new System.EventHandler(this.ClickedButtonValue);
            // 
            // button_Clear
            // 
            this.button_Clear.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_Clear.Location = new System.Drawing.Point(198, 195);
            this.button_Clear.Name = "button_Clear";
            this.button_Clear.Size = new System.Drawing.Size(105, 56);
            this.button_Clear.TabIndex = 16;
            this.button_Clear.Text = "C";
            this.button_Clear.UseVisualStyleBackColor = false;
            this.button_Clear.Click += new System.EventHandler(this.button_Clear_Click);
            // 
            // button_9
            // 
            this.button_9.BackColor = System.Drawing.Color.White;
            this.button_9.Location = new System.Drawing.Point(198, 250);
            this.button_9.Name = "button_9";
            this.button_9.Size = new System.Drawing.Size(105, 56);
            this.button_9.TabIndex = 11;
            this.button_9.Text = "9";
            this.button_9.UseVisualStyleBackColor = false;
            this.button_9.Click += new System.EventHandler(this.ClickedButtonValue);
            // 
            // button_Eq
            // 
            this.button_Eq.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_Eq.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Eq.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Eq.Location = new System.Drawing.Point(297, 415);
            this.button_Eq.Name = "button_Eq";
            this.button_Eq.Size = new System.Drawing.Size(105, 56);
            this.button_Eq.TabIndex = 15;
            this.button_Eq.Text = "=";
            this.button_Eq.UseVisualStyleBackColor = false;
            this.button_Eq.Click += new System.EventHandler(this.button_Eq_Click);
            // 
            // button_Multi
            // 
            this.button_Multi.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_Multi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Multi.Location = new System.Drawing.Point(297, 250);
            this.button_Multi.Name = "button_Multi";
            this.button_Multi.Size = new System.Drawing.Size(105, 56);
            this.button_Multi.TabIndex = 12;
            this.button_Multi.Text = "*";
            this.button_Multi.UseVisualStyleBackColor = false;
            this.button_Multi.Click += new System.EventHandler(this.OperationPerform);
            // 
            // button_Add
            // 
            this.button_Add.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_Add.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Add.Location = new System.Drawing.Point(297, 360);
            this.button_Add.Name = "button_Add";
            this.button_Add.Size = new System.Drawing.Size(105, 56);
            this.button_Add.TabIndex = 14;
            this.button_Add.Text = "+";
            this.button_Add.UseVisualStyleBackColor = false;
            this.button_Add.Click += new System.EventHandler(this.OperationPerform);
            // 
            // button_Sub
            // 
            this.button_Sub.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_Sub.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Sub.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Sub.Location = new System.Drawing.Point(297, 305);
            this.button_Sub.Name = "button_Sub";
            this.button_Sub.Size = new System.Drawing.Size(105, 56);
            this.button_Sub.TabIndex = 13;
            this.button_Sub.Text = "-";
            this.button_Sub.UseVisualStyleBackColor = false;
            this.button_Sub.Click += new System.EventHandler(this.OperationPerform);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textBox2);
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.comboBox2);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(402, 472);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Converter";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(26, 318);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(356, 97);
            this.textBox2.TabIndex = 13;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(26, 194);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(356, 32);
            this.textBox1.TabIndex = 10;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(91, 162);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "align me";
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.ItemHeight = 25;
            this.comboBox2.Items.AddRange(new object[] {
            "Binary",
            "Decimal"});
            this.comboBox2.SelectedIndex = 0;
            this.comboBox2.Location = new System.Drawing.Point(207, 94);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(175, 33);
            this.comboBox2.TabIndex = 5;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged_1);
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.ItemHeight = 25;
            this.comboBox1.Items.AddRange(new object[] {
            "Binary",
            "Decimal"});
            this.comboBox1.SelectedIndex = 0;
            this.comboBox1.Location = new System.Drawing.Point(26, 94);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(175, 33);
            this.comboBox1.TabIndex = 4;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged_1);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.Controls.Add(this.button_Convert);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(-4, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(403, 471);
            this.panel2.TabIndex = 14;
            // 
            // button_Convert
            // 
            this.button_Convert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Convert.Location = new System.Drawing.Point(275, 247);
            this.button_Convert.Name = "button_Convert";
            this.button_Convert.Size = new System.Drawing.Size(94, 31);
            this.button_Convert.TabIndex = 12;
            this.button_Convert.Text = "Convert";
            this.button_Convert.UseVisualStyleBackColor = true;
            this.button_Convert.Click += new System.EventHandler(this.button_Convert_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Converter";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(40, 287);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 25);
            this.label6.TabIndex = 11;
            this.label6.Text = "label6";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(40, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Enter";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.ClientSize = new System.Drawing.Size(402, 500);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Click += new System.EventHandler(this.ClickedButtonValue);
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox Result2;
        private System.Windows.Forms.TextBox Result1;
        protected System.Windows.Forms.Button button_Neg;
        protected System.Windows.Forms.Button button_0;
        protected System.Windows.Forms.Button button_Perc;
        protected System.Windows.Forms.Button button3;
        protected System.Windows.Forms.Button button_SqR;
        protected System.Windows.Forms.Button button_1;
        protected System.Windows.Forms.Button button_sq;
        protected System.Windows.Forms.Button button_2;
        protected System.Windows.Forms.Button button_fact;
        protected System.Windows.Forms.Button button_3;
        protected System.Windows.Forms.Button button_4;
        protected System.Windows.Forms.Button button_5;
        protected System.Windows.Forms.Button button10;
        protected System.Windows.Forms.Button button_6;
        protected System.Windows.Forms.Button button_ClearResult;
        protected System.Windows.Forms.Button button_7;
        protected System.Windows.Forms.Button button_div;
        protected System.Windows.Forms.Button button_8;
        protected System.Windows.Forms.Button button_Clear;
        protected System.Windows.Forms.Button button_9;
        protected System.Windows.Forms.Button button_Eq;
        protected System.Windows.Forms.Button button_Multi;
        protected System.Windows.Forms.Button button_Add;
        protected System.Windows.Forms.Button button_Sub;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button_Convert;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
    }
}

